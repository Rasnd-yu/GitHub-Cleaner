---
items:
 - rubygarage/nextjs6-graphql-client-tutorial
 - MikeBild/serverless-aws-cdk-ecommerce
 - alexander-elgin/atomic-react-redux
 - fernandohenriques/chat-app
 - marcelorl/tastin-front
 - kumilange/live-jazz-tokyo
 - JoshEvan/StockManagementSystem
 - yudwig/next-redux-todo
 - atomixinteractions/materialized
 - thepureinx000/crowdmeeting
display_name: Material-UI Projects Using Atomic Design
created_by: trentschnee
---
Find examples of projects utilizing Material-UI with the infamous atomic design system!